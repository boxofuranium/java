/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise9;

/**
 *
 * @author akay
 */

import java.lang.Math;

public class Triangle {
/*
class named Triangle
properties
- sideA
- sideB
- sideC

methods
- isValid
- calculatePerimeter
- calculateArea
*/
// Properties
private double sideA;
private double sideB;
private double sideC;
//end properties

// constructors
public Triangle(){
this.sideA = 0;
this.sideB = 0;
this.sideC = 0;
}

/**
* parametrized constructor
* @param sideA
* @param sideB
* @param sideC
*/
public Triangle(double sideA, double sideB, double sideC){
this.sideA = sideA;
this.sideB = sideB;
this.sideC = sideC;
}

// Methods
/**
* method to check if the given side lengths make a valid triangle
* @return true if the triangle is valid false otherwise
*/
public boolean isValid() {
boolean valid = false;
if (sideA + sideB > sideC && sideB + sideC > sideA && sideC + sideA > sideB) {
valid = true;
}
return valid;
}

/**
* method to calculate the perimeter of the triangle
* @return the sum of all sides of the triangle
*/
public double calculatePerimeter(){
double perimeter = -1;
if (isValid()){
perimeter = this.sideA + this.sideB + this.sideC;
}

return perimeter;
}

/**
* method to calculate the area of the triangle
* @return the area of the triangle
*/
public double calculateArea(){
double p = calculatePerimeter() / 2;
double area = -1;
if (isValid()){
area = Math.sqrt(p * (p - this.sideA) * (p - this.sideB) * (p - sideC));
}
return area;
}


//end methods

// region Getters and Setters
public double getSideA() {
return sideA;
}

public void setSideA(double sideA) {
if (sideA > 0) {
this.sideA = sideA;
}

}

public double getSideB() {
return sideB;
}

public void setSideB(double sideB) {
if (sideB > 0) {
this.sideB = sideB;
}
}

public double getSideC() {
return sideC;
}

public void setSideC(double sideC) {
if (sideC > 0) {
this.sideC = sideC;
}}}


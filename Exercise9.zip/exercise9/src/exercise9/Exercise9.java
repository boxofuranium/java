/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise9;

/**
 *
 * @author akay
 */
public class Exercise9 {

    /**
     * @param args the command line arguments
     */
  public static void main(String[] args){

// calling default constructor
Triangle triangle1 = new Triangle();

// calling parametrized constructor
Triangle triangle2 = new Triangle(3, 4, 5);

System.out.println("Area of triangle 1: " + triangle1.calculateArea());
System.out.println("Perimeter of triangle 2: " + triangle2.calculatePerimeter());
triangle1.setSideA(11);
triangle1.setSideB(12);
triangle1.setSideC(13);
System.out.println("Area of triangle 1 after modifying sides using setter methods: " + triangle1.calculateArea());
}

}
    


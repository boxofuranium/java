package javaapplication5;

import java.util.Scanner;

public class TriangleSide {
public static void TriangleSide()
{

        System.out.print("Side 1: ");
        Scanner input = new Scanner(System.in);
    double a;
a = input.nextDouble();

double b ;
System.out.print("Side 2: ");
b = input.nextDouble();

double c ;
System.out.print("Side 3: ");
double side = 0;
c = input.nextDouble();
    
    if(a+b>=c&&b+c>=a&&c+a>=b)
        System.out.println("\033[32;1;2mThis sides make a valid triangle");
    else
System.out.println("\033[31;1mThis sides do not make a valid triangle\033[0m");
    
    }
public static void main(String[] args){
    Scanner input = new Scanner(System.in);
    TriangleSide();
    System.out.println("\033[0;35mDo you want to try another set of numbers (1/0)?");
    int repeat = input.nextInt();

while (repeat == 1){
    TriangleSide();
    repeat = input.nextInt();
}    
}
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise8;

/**
 *
 * @author akay
 */
public class car {
    
    
    private String _make;
    private String _model; 
    private String _body;
    private int _year;
    private double _price;
    
    //
    
   public car(String make, String model, String body, int year, double price)
   {
       _make = make;
       _model = model;
       _body = body;
       _year = year;
       _price = price;
       
   }
   
   //
   
   public String getMake(){
       
       return _make;}
   
   public String getModel(){
       
       return _model;}
   
   public String getBody(){
     
       return _body;}
   
   public int getYear(){
       
       return _year;}
   
   public double getPrice(){
       
       return _price;}
   
   public void setMake(String make) {_make = make;}
   public void setModel(String model) {_model = model;}
   public void setBody(String body) {_body = body;}
   public void setYear(int year){_year = year;}
   public void setPrice(double price){_price = price;}
   
   
   
    @Override
   public String toString()
   {
return _make + _model + _body +Integer.toString(_year)+ Double.toString(_price);
       
   }
}
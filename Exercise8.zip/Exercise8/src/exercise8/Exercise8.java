/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise8;
import java.util.Scanner;
/**
 *
 * @author akay
 */
public class Exercise8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      boolean quit = false;
      String toQuit;
      String make, model, body;
      int year;
      double price;
      Scanner scan = new Scanner (System.in);
////////



while (!quit){
    
    System.out.println("Please enter make, model,body,year and price info");
    
    make = scan.next();
    model = scan.next();
    body = scan.next();
    year = scan.nextInt();
    price = scan.nextDouble();

car car = new car(" ", " "," ",0,0 );
    
  
  
    scan.nextLine();
    
    
    System.out.println("Data Stored : " + car);
    System.out.println("Press Q to quit or any key to continue" );
    toQuit = scan.next();
    
    if (toQuit.equalsIgnoreCase("Q"))
        quit = true;
}

        scan.close();        
        System.out.println("Bye");
    }
}
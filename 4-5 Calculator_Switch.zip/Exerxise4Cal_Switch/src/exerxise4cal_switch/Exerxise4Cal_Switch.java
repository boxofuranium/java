/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exerxise4cal_switch;

/**
 *
 * @author akay
 */
import java.util.Scanner;
public class Exerxise4Cal_Switch {
public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
// Display the menu
        int choice ;
        do {
            System.out.println("1) Calculate with fixed amount of numbers");
            System.out.println("2) Calculate with varying amount of numbers");
            System.out.println("3) Exit");

            choice = input.nextInt();
            switch (choice) {
                case 1: {
                    System.out.print("Enter number of elements: ");
                    int count = input.nextInt();
                    double sum = 0;
                    double average;
                    int a[] = new int[count];
                    System.out.println("Enter " + count + " values: ");
                    for (int i = 0; i < count; i++) {
                        a[i] = input.nextInt();
                        sum = sum + a[i];
                    }
                    average = (double) sum / count;
                    System.out.println("Sum:" + sum);
                    System.out.println("Average:" + average);
                }
                break;
                case 2: {
                    int count = 0;
                    double sum = 0;
                    double average;
                    System.out.print("Enter #" + (count + 1) + " (-99 to end): ");
                    int num = input.nextInt();
                    while (num != -99) {
                        sum = sum + num;
                        count++;
                        System.out.print("Enter #" + (count + 1) + " (-99 to end): ");
                        num = input.nextInt();
                    }
                    average = (double) sum / count;
                    System.out.println("Sum:" + sum);
                    System.out.println("Average:" + average);
                }
                break;
                case 3:
                    break;
                default:
                    System.out.println("Invalid choice entered");
            }
        } while (choice != 3);
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercise4cal;
import java.util.Scanner;
public class Exercise4Cal {
    
public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Display the menu
        int choice ;
        do
        {
            System.out.println("1) Calculate with fixed amount of numbers");
            System.out.println("2) Calculate with varying amount of numbers");
            System.out.println("3) Exit");
         
            choice = input.nextInt();
            if (choice == 1)
            {
                System.out.print("Enter number of elements: ");
                int count = input.nextInt();
                double sum = 0;
                double average;
                int a[] = new int[count];
                System.out.println("Enter " + count + " values: ");
                for (int i = 0; i < count; i++) {
                    a[i] = input.nextInt();
                    sum = sum + a[i];
                }
                average = (double) sum / count;
                System.out.println("Sum:" + sum);
                System.out.println("Average:" + average);
            }
            else if (choice == 2)
            {
                int count = 0;
                double sum = 0;
                double average;
                System.out.print("Enter #" + (count+1) + " (-99 to end): ");
                int num = input.nextInt();
                while (num != -99)
                {
                    sum = sum + num;
                    count++;
                    System.out.print("Enter #" + (count+1) + " (-99 to end): ");
                    num = input.nextInt();
                }
                average = (double) sum / count;
                System.out.println("Sum:" + sum);
                System.out.println("Average:" + average);
            }
        }while (choice != 3);
    }
}
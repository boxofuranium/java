package javaapplication5;

/**
 *
 * @author akay
 */

import javax.swing.JFrame;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author akay
 */
public class GUItriangle extends JFrame implements ActionListener {

    private final JTextField gt1;
    private final JTextField gt2;
    private final JTextField gt3;

    private final JLabel l1;
    private final JLabel l2;
    private final JLabel l3;

    private final JButton btn;

    JPanel panel = new JPanel(new GridLayout(4, 3));

    public GUItriangle() {
        super("Triangle Side Calculator");
        
        setLayout(new FlowLayout());
        l1 = new JLabel("Side 1: ");
        l2 = new JLabel("Side 2: ");
        l3 = new JLabel("Side 3: ");

        gt1 = new JTextField(4);
        gt2 = new JTextField(4);
        gt3 = new JTextField(4);
        panel.add(l1);
        panel.add(gt1);
        panel.add(l2);
        panel.add(gt2);
        panel.add(l3);
        panel.add(gt3);

        btn = new JButton("Calculate");
        panel.add(btn);
        add(panel);
        btn.addActionListener(this);
    }

    public static void main(String[] args) {
        GUItriangle gt = new GUItriangle();
        gt.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gt.setSize(500, 300);
        gt.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        double a = Double.parseDouble(gt1.getText());
        double b = Double.parseDouble(gt2.getText());
        double c = Double.parseDouble(gt3.getText());
      
        
        if (a + b >= c && b + c >= a && c + a >= b) {
           
            JOptionPane.showMessageDialog(null,"These sides make a valid triangle");
        } 
        
        else {
            
            JOptionPane.showMessageDialog(null,"These sides do not make a valid triangle");
        }
       
    
    }
    
  
}
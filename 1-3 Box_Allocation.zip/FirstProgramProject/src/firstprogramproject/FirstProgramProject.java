/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */package firstprogramproject;

import java.util.Scanner;

public class FirstProgramProject
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        System.out.println("Welcome to Box Price Calculator");
        
        int boxVol = 20 ;
        double price_each_box = 2.99;
        System.out.print("Bottles :");
        Scanner input = new Scanner(System.in);
        int numberOfbottles ;
        
        while ((numberOfbottles = input.nextInt()) < 0)     {
        System.out.println("\033[31;1mNegative numbers are not allowed. Please try again");}
        int box = (numberOfbottles / boxVol);
        System.out.println("Box Needed : " + box);
        double totPrice = (box * price_each_box);
        
        System.out.println("Total Cost : $" + totPrice);
        int leftOver = (numberOfbottles -(box * boxVol));
        System.out.println("Unboxed :" + leftOver);
        
    }
    
}